module learning.java {
    requires hibernate.jpa;
    requires json.simple;
    requires hibernate.core;
    requires commons.csv;
    requires transitive java.naming;
    requires jdk.incubator.httpclient;
}